const express = require('express')
const dotenv = require('dotenv')
const mongoose = require('mongoose')
//for engine
const ejs = require('ejs')
const User = require('./models/User')
//for password encrypting
const crypt = require('bcryptjs')
//for session
const session = require('express-session')
const mongodbstore = require('connect-mongodb-session')(session)


const app = express()
const port = 3400
dotenv.config()
app.set('view engine' , 'ejs')
app.use(express.static('public'))
app.use(express.urlencoded({extended:true}))



mongoose.connect(process.env.Mongo_Url)
.then(()=>{
    console.log('mongo db connected successfully')
})
.catch(()=>{
    console.log('connection failed')
})

const store = new mongodbstore({
    uri : process.env.Mongo_Url,
    collection : 'mysession'
})

app.use(session({
    secret:'this is secret',
    resave:false,
    saveUninitialized : false,
    store : store
}))

const checkauth = (req,res,next)=>{
    if (req.session.isauth){
        next()
    }else{
        res.redirect('/signup')
    }
}
//routes
app.get('/signup' , (req,res)=>{
    res.render('register')
})

app.get('/log',(req,res)=>{
    res.render('login')
})

app.get('/dashboard' , checkauth , (req,res)=>{
    res.render('welcome')
})

app.post('/register',async(req,res)=>{
    const {username,email,password}=req.body
    let user = await User.findOne({email})
    if (user){
        return res.redirect('/signup')
    }
    const hashpassword = await crypt.hash(password , 12)

    user = new User({
        username,
        email,
        password : hashpassword
    })
    await user.save()
    req.session.data = user.username
    res.redirect('/log')
})


app.post('/user-login', async(req,res)=>{
    const {email,password} = req.body
    const user = await User.findOne({email})
    if (!user){
       return res.redirect('/log')
    }

    const chekc = await crypt.compare(password,user.password)
    if (!chekc){
        return res.redirect('/log')
    }
    req.session.isauth = true
    res.redirect('/dashboard')
})

app.post('/logout', (req, res) => {
    req.session.destroy((err) => {
        if (err) {
            res.redirect('/signup');
        } else {
            res.redirect('/log'); // or another appropriate page
        }
    });
});


app.listen(port , ()=>{
    console.log(`server started and listening at ${port}`)
})


