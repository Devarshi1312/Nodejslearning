const Employee=require('../models/Employee')
const createemployee = async(req,res)=>{
    try{
        const {name,email,phone,city}=req.body

        const employee = new Employee({
            name,email,phone,city
        })
        await employee.save()
        res.status(201).json(employee)
    }
    catch(err){
        console.log("there is an error",err)
        res.status(500).json({message:'server error'})
    }
}

const getemployees = async(req,res)=>{
    try{
        const employee=await Employee.find()
        res.status(201).json(employee)
    }
    catch(err){
        console.log("there is an error")
        res.status(500).json({message:"server error"})
    }
}

const single=async(req,res)=>{
    try{
        const employee = await Employee.findById(req.params.id)

        if(!employee){
            return res.status(404).json({message:"employee not found"})
        }
        res.status(201).json(employee)
    }
    catch(err){
        console.log("there is an error")
        res.status(500).json({message:"server error"})
    }
}

const updateemployee = async(req,res)=>{
    try{
        const {name,email,phone,city} = req.body

        const myemployee = await Employee.findByIdAndUpdate(
            req.params.id,
            {
                name,email,phone,city
            }
        )
        if (!myemployee){
            return res.status(404).json({message:"employee not found"})
        }
        res.status(200).json(myemployee)
    }
    catch{
        console.log("something went wrong")
        res.status(500).json({message:"server error"})
    }
}

const deleteemployee = async(req,res)=>{
    try{
        const deleteemp = await Employee.findByIdAndDelete(req.params.id)
        res.status(204).send()
    }
    catch{
        console.log("something went wrong")
        res.status(500).json({message:"server error"})
    }
}

module.exports = {createemployee , getemployees , single, updateemployee , deleteemployee}