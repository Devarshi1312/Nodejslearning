const express = require('express')
const dotenv = require('dotenv')
const mongoose = require('mongoose')
const bodyparser= require('body-parser')
const {MongoClient} = require('mongodb')
const employeeRoutes = require('./routes/employeeroutes')
const app=express()
const PORT = 3000
dotenv.config()
app.use(bodyparser.json())
//ways to connect to a mongobd
//using MongoClient
// MongoClient.connect(process.env.Mongo_url)
// .then(()=>{
//     console.log("mongodb connected successfully")
// })
// .catch(()=>{
//     console.log("didnt connect")
// })

//using mongoose
mongoose.connect(process.env.Mongo_url)
.then(()=>{
    console.log("mongodb connected successfully")
})
.catch(()=>{
    console.log("didnt connect")
})

app.use('/emp', employeeRoutes)

app.listen(PORT,()=>{
    console.log(`server is listening ${PORT}`)
})