const express = require('express')
const router = express.Router()
const employeeController = require('../controllers/EmployeeController')
// const model=require('../models/Employee')

//get post put delete 

router.post('/add-employee',employeeController.createemployee)

router.get('/getall',employeeController.getemployees)

router.get('/single/:id',employeeController.single)

router.put('/update/:id',employeeController.updateemployee)

router.delete('/del/:id',employeeController.deleteemployee)

module.exports= router